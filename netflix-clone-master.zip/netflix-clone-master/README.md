# PWJ Netflix Clone

A project the students are building to learn the basics of HTML, CSS, and JavaScript
